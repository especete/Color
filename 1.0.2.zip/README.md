Color
=====

- Create a random color, with matching set.
- Compare selected color to named ones.
- Save set.

In the process:

- Two-state animated SVG button. (Needs to be three, to add a static onLoad).