<?php
// Stop fishing, please.
?>