// JavaScript Document

var coco = angular.module('coco', ['ui.bootstrap']);